// services/dichVuService.js
import { apiClient } from './apiClient';

/**
 * Unwrap response từ BaseController.resSuccess():
 *   Backend trả: { status, message, data: T }
 *   Interceptor chỉ unwrap khi data.data là Array → object KHÔNG bị tự unwrap
 *   → Hàm này unwrap thủ công → trả thẳng T
 */
function unwrapDto(responseData) {
  if (!responseData) return null;
  // Dạng { status, message, data: DichVuDTO }
  if (
    responseData.data !== undefined &&
    !Array.isArray(responseData.data) &&
    (responseData.status !== undefined || responseData.message !== undefined)
  ) {
    return responseData.data;
  }
  // Đã là DTO thuần
  return responseData;
}

export const dichVuService = {
  getAllDichVu: async () => {
    const response = await apiClient.get('/api/v1/dich-vu');
    return response.data;
  },

  /**
   * Trả thẳng DichVuDTO: { maDV, tenDV, gia, moTa, ... }
   * Đã unwrap BaseController wrapper.
   */
  getDichVuById: async (id) => {
    const response = await apiClient.get(`/api/v1/dich-vu/${id}`);
    return unwrapDto(response.data);
  },

  createDichVu: (data) => apiClient.post('/api/v1/dich-vu', data),
  deleteDichVu: (id) => apiClient.delete(`/api/v1/dich-vu/${id}`),
  getDichVuSummary: () => apiClient.get('/api/v1/dich-vu/summary'),
  searchDichVu: (params) => apiClient.get('/api/v1/dich-vu/search', { params }),
  getNextCode: () => apiClient.get('/api/v1/dich-vu/next-code'),
  getByGiaRange: (min = 0, max = 999999999) =>
    apiClient.get('/api/v1/dich-vu/gia-range', { params: { min, max } }),
  checkExistsName: (tenDV) =>
    apiClient.get('/api/v1/dich-vu/exists-name', { params: { tenDV } }),
};
