// services/dichVuService.js
import { apiClient } from './apiClient';

export const dichVuService = {
  // GET /api/v1/dich-vu - Lấy toàn bộ dịch vụ
  getAllDichVu: async () => {
    const response = await apiClient.get('/api/v1/dich-vu');
    return response.data;
  },

  /**
   * GET /api/v1/dich-vu/{id} - Lấy chi tiết dịch vụ theo ID
   * Backend dùng BaseController.resSuccess() → { status, message, data: DichVuDTO }
   * Interceptor chỉ unwrap khi data.data là Array → object KHÔNG bị unwrap
   * → trả về response.data nguyên để caller tự unwrap: dvRes.data?.gia hoặc dvRes?.gia
   * 
   * Hàm này unwrap sẵn → trả thẳng DichVuDTO: { maDV, tenDV, gia, moTa, ... }
   */
  getDichVuById: async (id) => {
    const response = await apiClient.get(`/api/v1/dich-vu/${id}`);
    // response.data có thể là:
    //   - { status, message, data: { maDV, gia } }  ← BaseController chưa unwrap
    //   - { maDV, gia, ... }                         ← nếu interceptor đã xử lý
    const raw = response.data;
    if (raw && raw.data && !Array.isArray(raw.data) && (raw.data.maDV || raw.data.gia !== undefined)) {
      return raw.data; // unwrap BaseController wrapper → DichVuDTO thuần
    }
    return raw; // đã là DichVuDTO thuần
  },

  // POST /api/v1/dich-vu - Tạo mới hoặc cập nhật dịch vụ
  createDichVu: (data) => apiClient.post('/api/v1/dich-vu', data),

  // DELETE /api/v1/dich-vu/{id} - Xóa dịch vụ
  deleteDichVu: (id) => apiClient.delete(`/api/v1/dich-vu/${id}`),

  // GET /api/v1/dich-vu/summary
  getDichVuSummary: () => apiClient.get('/api/v1/dich-vu/summary'),

  // GET /api/v1/dich-vu/search
  searchDichVu: (params) => apiClient.get('/api/v1/dich-vu/search', { params }),

  // GET /api/v1/dich-vu/next-code
  getNextCode: () => apiClient.get('/api/v1/dich-vu/next-code'),

  // GET /api/v1/dich-vu/gia-range
  getByGiaRange: (min = 0, max = 999999999) =>
    apiClient.get('/api/v1/dich-vu/gia-range', { params: { min, max } }),

  // GET /api/v1/dich-vu/exists-name
  checkExistsName: (tenDV) =>
    apiClient.get('/api/v1/dich-vu/exists-name', { params: { tenDV } }),
};
